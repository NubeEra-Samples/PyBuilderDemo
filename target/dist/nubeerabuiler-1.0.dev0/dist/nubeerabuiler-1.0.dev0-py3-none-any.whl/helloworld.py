import sys

def helloworld(out):
    out.write("Welcome world of Python\n")